﻿int a=5;
int b=3;

if (a==b)
{
    Console.WriteLine("Son iguale");
}else{
    Console.WriteLine("No son iguales");
}